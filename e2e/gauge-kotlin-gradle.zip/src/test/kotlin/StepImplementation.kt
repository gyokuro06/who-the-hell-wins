import com.thoughtworks.gauge.Step
import com.thoughtworks.gauge.Table

class StepImplementation {

    private lateinit var vowels: HashSet<Char>

    @Step("Vowels in English language are <vowelString>.")
    fun setLanguageVowels(vowelString: String) {
        vowels = HashSet()
        vowelString.toCharArray()
            .forEach { vowels.add(it) }
    }

    @Step("The word <word> has <expectedCount> vowels.")
    fun verifyVowelsCountInWord(word: String, expectedCount: Int) {
        val actualCount = countVowels(word)
        assert(expectedCount == actualCount)
    }

    @Step("Almost all words have vowels <wordsTable>")
    fun verifyVowelsCountInMultipleWords(wordsTable: Table) {
        wordsTable.tableRows
            .forEach {
                val expectedCount = it.getCell("Vowel Count").toInt()
                val actualCount = countVowels(it.getCell("Word"))

                assert(expectedCount == actualCount)
            }
    }

    private fun countVowels(word: String): Int {
        var count = 0
        word.toCharArray()
            .forEach {
                if (vowels.contains(it)) {
                    count++
                }
            }
        return count
    }
}