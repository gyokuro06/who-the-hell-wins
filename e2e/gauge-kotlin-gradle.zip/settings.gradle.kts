rootProject.name = "gauge-kotlin-gradle"

plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "1.0.0"
}
